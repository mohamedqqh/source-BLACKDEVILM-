from telethon import events
import asyncio

async def setup_spam(client):
    
    # ✦ سبام برو ✦
    @client.on(events.NewMessage(pattern='.سبام برو (\\d+) (.+)'))
    async def pro_spam_handler(event):
        try:
            count = int(event.pattern_match.group(1))
            text = event.pattern_match.group(2)
            
            await event.reply(f"✦ بدء السبام المتقدم لـ {count} رسالة")
            for i in range(count):
                await event.respond(f"✦ {text} - {i+1}")
                await asyncio.sleep(0.1)
        except:
            await event.reply("✦ استخدم: .سبام برو 10 نص")

    # ✦ رايد غير محدود ✦
    @client.on(events.NewMessage(pattern='.رايد غير محدود (.+)'))
    async def unlimited_raid_handler(event):
        try:
            text = event.pattern_match.group(1)
            await event.reply("✦ بدء الرايد غير المحدود")
            for i in range(100):
                await event.respond(f"✦ {text}")
                await asyncio.sleep(0.1)
        except:
            await event.reply("✦ استخدم: .رايد غير محدود نص")