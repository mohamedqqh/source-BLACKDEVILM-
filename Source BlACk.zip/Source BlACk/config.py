import os

# بيانات السورس الأساسية
SOURCE_NAME = "✦ 𝐒𝐎𝐔𝐑𝐂𝐄 𝐁𝐋𝐀𝐂𝐊 𝐃𝐄𝐕𝐈𝐋 ✦"
DEV_USERNAME = "@BL_TH"
DEV_ID = 8051547891
CHANNEL_USERNAME = "@S_S_H_44"
IMAGE_URL = "https://i.ibb.co/xK5qXxwQ/IMG-20251021-001430-162.jpg"

# بيانات API
API_ID = 12548557
API_HASH = "b4ddb955fd4c18d7f38d0dd784e2c760"
BOT_TOKEN = "8352876513:AAFoLDS8NbDd0tMNHg0kkghY177WiuM_Xyw"

# إعدادات الحماية
MAX_BOTS = 20
MAX_RAID_COUNT = 100
ADMIN_IDS = [DEV_ID, 123456789]  # أضف ايدي الأدمن هنا

# المسارات
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SESSIONS_DIR = os.path.join(BASE_DIR, "sessions")
DOWNLOADS_DIR = os.path.join(BASE_DIR, "downloads")

# إنشاء المجلدات إذا لم تكن موجودة
os.makedirs(SESSIONS_DIR, exist_ok=True)
os.makedirs(DOWNLOADS_DIR, exist_ok=True)
os.makedirs(os.path.join(DOWNLOADS_DIR, "photos"), exist_ok=True)
os.makedirs(os.path.join(DOWNLOADS_DIR, "voices"), exist_ok=True)
os.makedirs(os.path.join(DOWNLOADS_DIR, "stories"), exist_ok=True)

print(f"✅ تم تحميل إعدادات {SOURCE_NAME}")