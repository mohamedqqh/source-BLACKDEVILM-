#!/usr/bin/env python3
from telethon import TelegramClient, events, Button, types
import asyncio
import sqlite3
import os
import random
from datetime import datetime
from config import 

print(f"""
\033[1;35m
╔══════════════════════════════════════╗
║                                      ║
║           ✦ 𝐒𝐎𝐔𝐑𝐂𝐄 𝐁𝐋𝐀𝐂𝐊 𝐃𝐄𝐕𝐈𝐋 ✦     ║
║           Userbot Factory            ║
║          Developed by {DEV_USERNAME}   ║
║                                      ║
╚══════════════════════════════════════╝
\033[0m
""")

# قاعدة البيانات
conn = sqlite3.connect('database/users.db', check_same_thread=False)
cursor = conn.cursor()

# إنشاء الجداول
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        join_date TEXT,
        is_premium INTEGER DEFAULT 0,
        is_admin INTEGER DEFAULT 0
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS user_titles (
        user_id INTEGER PRIMARY KEY,
        title TEXT,
        set_by INTEGER,
        set_date TEXT
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS saved_photos (
        photo_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        file_path TEXT,
        save_date TEXT
    )
''')
conn.commit()

async def main():
    client = TelegramClient(f"{SESSIONS_DIR}/BLACK_DEVIL", API_ID, API_HASH)
    
    await client.start()
    me = await client.get_me()
    
    print(f"\033[1;32m✦ تم التسجيل كـ: {me.first_name}\033[0m")
    print(f"\033[1;36m✦ ايدي الحساب: {me.id}\033[0m")
    print(f"\033[1;33m✦ اليوزر: @{me.username}\033[0m")
    
    # ✦ أوامر السبام المتقدم ✦
    @client.on(events.NewMessage(pattern='.مكرر (.)'))
    async def spam_handler(event):
        try:
            count, text = event.pattern_match.group(1).split(" ", 1)
            count = int(count)
            await event.delete()
            for i in range(count):
                await event.respond(f"✦ {text}")
                await asyncio.sleep(0.2)
        except: 
            await event.reply("✦ استخدم: .مكرر 10 نص")

    @client.on(events.NewMessage(pattern='.توجيه (.)'))
    async def forward_handler(event):
        try:
            count = int(event.pattern_match.group(1))
            if event.reply_to_msg_id:
                for i in range(count):
                    await client.forward_messages(event.chat_id, event.reply_to_msg_id, event.chat_id)
                    await asyncio.sleep(0.3)
        except: 
            await event.reply("✦ استخدم: .توجيه 5 (بالرد على الرسالة)")

    # ✦ أوامر المجموعات ✦
    @client.on(events.NewMessage(pattern='.انضم (.)'))
    async def join_handler(event):
        link = event.pattern_match.group(1)
        try:
            await client.join_chat(link)
            await event.reply("✦ تم الانضمام بنجاح")
        except: 
            await event.reply("✦ خطأ في الانضمام")

    @client.on(events.NewMessage(pattern='.غادر'))
    async def leave_handler(event):
        try:
            await client.leave_chat(event.chat_id)
            await event.reply("✦ تم المغادرة")
        except: 
            await event.reply("✦ خطأ في المغادرة")

    # ✦ أوامر سرقة الأسماء ✦
    @client.on(events.NewMessage(pattern='.سرقه'))
    async def steal_name(event):
        if event.reply_to_msg_id:
            replied = await event.get_reply_message()
            target_name = replied.sender.first_name
            await client(UpdateProfileRequest(
                first_name=target_name,
                last_name=""
            ))
            await event.reply(f"✦ تم سرقة اسم {target_name} بنجاح")

    @client.on(events.NewMessage(pattern='.سرقه صوره'))
    async def steal_photo(event):
        if event.reply_to_msg_id:
            replied = await event.get_reply_message()
            if replied.sender.photo:
                photo = await client.download_profile_photo(replied.sender)
                await client(UploadProfilePhotoRequest(await client.upload_file(photo)))
                await event.reply("✦ تم سرقة الصورة بنجاح")

    # ✦ أوامر الترفيه ✦
    @client.on(events.NewMessage(pattern='.حب'))
    async def send_love(event):
        hearts = ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "💖", "💝"]
        fire_heart = "".join(random.choices(hearts, k=10))
        await event.reply(f"✦ {fire_heart}")

    @client.on(events.NewMessage(pattern='.رقص'))
    async def dance(event):
        dance_moves = ["💃", "🕺", "👯", "🎉", "🎊"]
        dance_combo = " ".join(random.choices(dance_moves, k=8))
        await event.reply(f"✦ {dance_combo}")

    @client.on(events.NewMessage(pattern='.صراحه'))
    async def truth_game(event):
        questions = [
            "✦ آخر مرة كذبت فيها؟",
            "✦ أغرب حلم حلمته؟", 
            "✦ أكثر حاجة تخاف منها؟",
            "✦ أمنية كنت تتمناها وتحققت؟"
        ]
        await event.reply(f"🎯 {random.choice(questions)}")

    # ✦ أوامر المعلومات ✦
    @client.on(events.NewMessage(pattern='.معلومات'))
    async def info_handler(event):
        user = await event.get_sender()
        await event.reply(f"""
✦ معلومات الحساب ✦

👤 الاسم: {user.first_name}
🆔 ايدي: {user.id}
📞 اليوزر: @{user.username or "لا يوجد"}

✦ معلومات البوت ✦
🤖 البوت: {me.first_name}
👑 المطور: {DEV_USERNAME}
📢 القناة: {CHANNEL_USERNAME}

✦ {SOURCE_NAME} ✦
        """)

    @client.on(events.NewMessage(pattern='.الاحصائيات'))
    async def stats_handler(event):
        dialogs = await client.get_dialogs()
        groups = channels = users = 0
        for dialog in dialogs:
            if dialog.is_group: groups += 1
            elif dialog.is_channel: channels += 1
            else: users += 1
        
        await event.reply(f"""
✦ إحصائيات الحساب ✦

👤 المستخدم: {me.first_name}
🆔 الايدي: {me.id}

💬 الدردشات: {len(dialogs)}
👥 المجموعات: {groups}
📢 القنوات: {channels}
🔸 المستخدمين: {users}

✦ {SOURCE_NAME} ✦
        """)

    # ✦ أوامر حفظ الصور ✦
    @client.on(events.NewMessage)
    async def auto_save_photos(event):
        if event.photo:
            try:
                photo_path = await event.download_media(file=f"downloads/photos/{event.sender_id}/")
                cursor.execute('INSERT INTO saved_photos (user_id, file_path, save_date) VALUES (?, ?, ?)',
                             (event.sender_id, photo_path, datetime.now().isoformat()))
                conn.commit()
            except:
                pass

    @client.on(events.NewMessage(pattern='.صوري'))
    async def show_my_photos(event):
        cursor.execute('SELECT COUNT() FROM saved_photos WHERE user_id = ?', (event.sender_id,))
        photo_count = cursor.fetchone()[0]
        await event.reply(f"✦ عدد صورك المحفوظة: {photo_count} صورة")

    # ✦ نظام الألقاب ✦
    @client.on(events.NewMessage(pattern='.سجل (@\\w+|\\d+) (.+)'))
    async def set_user_title(event):
        try:
            target_user = await event.get_input_user()
            title = event.pattern_match.group(2)
            cursor.execute('INSERT OR REPLACE INTO user_titles (user_id, title, set_by, set_date) VALUES (?, ?, ?, ?)',
                         (target_user.user_id, title, event.sender_id, datetime.now().isoformat()))
            conn.commit()
            await event.reply(f"✦ تم تسجيل اللقب: {title}")
        except:
            await event.reply("✦ خطأ في التسجيل")

    # ✦ أوامر البريميوم ✦
    @client.on(events.NewMessage(pattern='.مميزات'))
    async def premium_features_handler(event):
        await event.reply(f"""
✦ المميزات المدفوعة - مجاناً لك ✦

🎯 السبام المتقدم
✦ سبام برو متقدم
✦ رايد غير محدود
✦ توجيه جماعي

📸 الحفظ التلقائي  
✦ حفظ الصور تلقائياً
✦ حفظ الرسائل الصوتية
✦ نسخ المحادثات

👥 الإجراءات الجماعية
✦ انضمام جماعي
✦ مغادرة جماعية
✦ طرد جماعي

🛠️ الأدوات المتقدمة
✦ أدوات متقدمة
✦ نسخ محادثات
✦ استيلاء مجموعات

✦ لتفعيل المميزات:
.تفعيل بريميوم

✦ {SOURCE_NAME} ✦
        """)

    @client.on(events.NewMessage(pattern='.تفعيل بريميوم'))
    async def activate_premium(event):
        cursor.execute('UPDATE users SET is_premium = 1 WHERE user_id = ?', (event.sender_id,))
        conn.commit()
        await event.reply(f"""
✦ تم تفعيل البريميوم بنجاح ✦

🎉 مبروك! الآن لديك جميع المميزات المدفوعة مجاناً

✨ يمكنك استخدام:
✦ جميع أوامر السبام المتقدم
✦ أدوات الحفظ التلقائي
✦ الإجراءات الجماعية
✦ الأدوات المتقدمة

✦ اكتب .مميزات لمشاهدة كل المميزات

✦ {SOURCE_NAME} ✦
        """)

    # ✦ الترحيب التلقائي ✦
    @client.on(events.ChatAction)
    async def welcome_handler(event):
        if event.user_joined:
            user = await event.get_user()
            try:
                await client.send_message(
                    event.chat_id,
                    f"""✨ • ━━━━━━ •✨• ━━━━━━ •

🎭 أهلاً بك في عالم {SOURCE_NAME} 🎭

• ━━━━━━ •✨• ━━━━━━ •

🌀 {user.first_name} نورت المكان بوجودك 🌀

⚡ سورس متكامل بكل ما تحتاجه

🎯 جرب هذه الأوامر:
.معلومات ✦ معلومات حسابك
.سرقه ✦ سرقة اسم شخص  
.حب ✦ إرسال قلب ناري
.صراحه ✦ أسئلة صريحة
.مميزات ✦ المميزات المتاحة

• ━━━━━━ •✨• ━━━━━━ •

👑 المطور: {DEV_USERNAME}
📢 القناة: {CHANNEL_USERNAME}

• ━━━━━━ •✨• ━━━━━━ •""",
                    file=IMAGE_URL
                )
            except Exception as e:
                print(f"✦ خطأ في الترحيب: {e}")

    print(f"✦ {SOURCE_NAME} شغال الآن! اكتب .معلومات في أي دردشة")
    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())