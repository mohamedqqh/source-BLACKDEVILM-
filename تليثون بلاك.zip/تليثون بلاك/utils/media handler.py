import os
import asyncio
from telethon import utils

class MediaHandler:
    def __init__(self, client):
        self.client = client
    
    async def download_media(self, message, folder="downloads"):
        """تحميل الميديا من الرسالة"""
        if message.media:
            file_path = await message.download_media(file=folder)
            return file_path
        return None
    
    async def get_user_photos(self, user_id, limit=10):
        """الحصول على صور مستخدم"""
        photos = []
        async for photo in self.client.iter_profile_photos(user_id, limit=limit):
            photos.append(photo)
        return photos
    
    async def save_story(self, user_id, story_id):
        """حفظ ستوري"""
        try:
            story = await self.client.get_stories(user_id, story_id)
            if story:
                file_path = await self.download_media(story[0], "downloads/stories")
                return file_path
        except:
            return None