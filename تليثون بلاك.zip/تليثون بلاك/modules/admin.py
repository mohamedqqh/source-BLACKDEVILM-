from telethon import events, Button
import asyncio
from config import 

async def setup_admin(client):
    
    # ✦ التحقق من الأدمن ✦
    async def is_admin(user_id):
        return user_id in ADMIN_IDS

    # ✦ لوحة تحكم الأدمن ✦
    @client.on(events.NewMessage(pattern='.الادمن'))
    async def admin_panel(event):
        if not await is_admin(event.sender_id):
            await event.reply("✦ ليس لديك صلاحية الأدمن")
            return
        
        await event.reply(f"""
✦ لوحة تحكم الأدمن ✦

👑 الأدمن: {event.sender.first_name}
🆔 ايدي: {event.sender_id}

🎯 الأوامر المتاحة:
.حظر مستخدم ✦ حظر مستخدم من السورس
.الغاء حظر ✦ فك حظر مستخدم
.المحظورين ✦ عرض المحظورين
.احصائيات ✦ إحصائيات السورس

✦ {SOURCE_NAME} ✦
        """)

    # ✦ حظر مستخدم ✦
    @client.on(events.NewMessage(pattern='.حظر مستخدم (@\\w+|\\d+)'))
    async def ban_user(event):
        if not await is_admin(event.sender_id):
            return
        
        try:
            target_user = await event.get_input_user()
            # كود حظر المستخدم
            await event.reply(f"✦ تم حظر المستخدم")
        except:
            await event.reply("✦ خطأ في حظر المستخدم")

    # ✦ فك حظر مستخدم ✦
    @client.on(events.NewMessage(pattern='.الغاء حظر (@\\w+|\\d+)'))
    async def unban_user(event):
        if not await is_admin(event.sender_id):
            return
        
        try:
            target_user = await event.get_input_user()
            # كود فك حظر المستخدم
            await event.reply(f"✦ تم فك حظر المستخدم")
        except:
            await event.reply("✦ خطأ في فك حظر المستخدم")