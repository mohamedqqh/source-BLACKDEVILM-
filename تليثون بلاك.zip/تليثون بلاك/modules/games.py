from telethon import events, Button
import asyncio
import random

async def setup_games(client):
    
    # ✦ لعبة الروليت ✦
    @client.on(events.NewMessage(pattern='.روليت'))
    async def roulette_game(event):
        options = ["🎯 ربحت!", "💥 خسرت!", "🎁 جائزة!", "🔄 جرب مرة أخرى!"]
        result = random.choice(options)
        await event.reply(f"""
✦ لعبة الروليت ✦

🎰 النتيجة: {result}
👤 اللاعب: {event.sender.first_name}

✦ {SOURCE_NAME} ✦
        """)

    # ✦ لعبة الرقم العشوائي ✦
    @client.on(events.NewMessage(pattern='.تخمين (.+)'))
    async def guess_number(event):
        try:
            user_guess = int(event.pattern_match.group(1))
            correct_number = random.randint(1, 10)
            
            if user_guess == correct_number:
                message = "🎉 مبروك! فزت!"
            else:
                message = f"💥 للأسف! الرقم الصحيح كان: {correct_number}"
            
            await event.reply(f"""
✦ لعبة التخمين ✦

🎯 تخمينك: {user_guess}
🔢 الرقم الصحيح: {correct_number}

{message}

✦ {SOURCE_NAME} ✦
            """)
        except:
            await event.reply("✦ استخدم: .تخمين رقم")

    # ✦ لعبة الصراحة ✦
    @client.on(events.NewMessage(pattern='.سؤال'))
    async def truth_question(event):
        questions = [
            "✦ آخر مرة كذبت فيها؟",
            "✦ أغرب حلم حلمته؟",
            "✦ أكثر حاجة تخاف منها؟", 
            "✦ أمنية كنت تتمناها وتحققت؟",
            "✦ آخر مرة بكيت فيها؟",
            "✦ أفضل ذكرى في حياتك؟",
            "✦ أسوأ قرار اتخذته؟",
            "✦ حلمك المستقبلي؟"
        ]
        await event.reply(f"""
✦ سؤال صراحة ✦

❓ {random.choice(questions)}

👤 لللاعب: {event.sender.first_name}

✦ {SOURCE_NAME} ✦
        """)

    # ✦ لعبة الحظ ✦
    @client.on(events.NewMessage(pattern='.حظي'))
    async def my_luck(event):
        luck_options = [
            "🍀 حظك حلو اليوم!",
            "☠️ انتبه اليوم!",
            "🎯 ركز في أهدافك!", 
            "💸 فلوس قادمة!",
            "❤️ حب قادم!",
            "🏆 نجاح كبير!",
            "🚀 مغامرة جديدة!",
            "🎁 مفاجأة سعيدة!"
        ]
        await event.reply(f"""
✦ حظك اليوم ✦

🔮 {random.choice(luck_options)}

👤 لـ: {event.sender.first_name}

✦ {SOURCE_NAME} ✦
        """)