#!/usr/bin/env python3
import os
import requests
import json

def check_updates():
    """التحقق من التحديثات"""
    print("✦ جاري التحقق من التحديثات...")
    
    # هنا بتكون رابط التحديثات من GitHub
    update_url = "https://api.github.com/repos/blackdevil/source/releases/latest"
    
    try:
        response = requests.get(update_url)
        if response.status_code == 200:
            latest_version = response.json()['tag_name']
            print(f"✅ أحدث إصدار: {latest_version}")
            return True
        else:
            print("❌ لا يمكن الوصول للتحديثات")
            return False
    except:
        print("❌ خطأ في التحقق من التحديثات")
        return False

def update_source():
    """تحديث السورس"""
    print("🔄 جاري تحديث السورس...")
    os.system("git pull origin main")
    print("✅ تم التحديث بنجاح")

if __name__ == "__main__":
    if check_updates():
        update_source()